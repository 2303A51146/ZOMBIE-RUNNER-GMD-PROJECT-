DEAD CITY: AFTER DARK - COMPLETE DIRECT CONTENTS PROJECT
Target Unity 6000.6.0f1. Not compiled or play-tested in Unity here.

INSTALL AS A FRESH PROJECT
Extract ZIP into a NEW empty folder called DeadCityAfterDark.
Assets, Packages, ProjectSettings are directly at ZIP root (no wrapper).
Unity Hub > Add project from disk > select DeadCityAfterDark.
Wait for compilation. Editor setup generates Assets/DeadCity.unity and opens it.
If necessary: Dead City > Create or Reset Game Scene. Play > START RUN.
Do NOT merge with previous projects or Combat add-on: duplicate classes/scripts.

A/D or arrows: lanes. Space/Up jump. S/Down slide. F shoot.
E auto-fire on/off. M music and wind mute. R retry after collision.
Click Game view for keyboard focus; FIRE/AUTO buttons also provided.

PICKUPS: Cyan +36 ammo. Orange rapid rifle (12s). Purple spread shotgun (12s).
Green shield (15s, absorbs one hit). Non-ammo pickups also give +18 rounds.
Base rifle: 60-unit range, current lane. Shotgun: three lanes, 38-unit range,
two damage per pellet. Large zombies need two normal shots.
No car destruction. One obstacle hit ends run unless shield is active.
Pipes require slide; barricades/rubble can be jumped. Ammo starts at 36.
Retry resets combat and obstacles; best distance saved locally.

Includes colored vehicle variants/taxis/emergency lights, building/window
colors, dusk fog, emissive lamps/windows, distant humanoid survivors,
three zombie variants, glowing eyes, moving legs, rubble/barricades/pipes,
rifle, ammo/powerups, tracers/impact particles, score/ammo/kills HUD,
procedural gunshots, footsteps, kill effects, three horror vocal variants,
periodic horror calls, wind and generated electronic soundtrack.

LIMITATIONS: Stylized primitive meshes, NOT realistic character models.
Horror sounds are synthesized, NOT recorded screams or human performances.
No external models/audio/assets or downloads except Unity package import.
No mobile movement controls, pause, health bars or production collision QA.
Obstacle detection is simplified lane/proximity logic. Audio is nonspatial.
Player weapon mesh is shared across weapon power modes. Distant humans static.
No promise of compatibility/testing beyond source targeting this Unity version.
Source and script .meta included; scene created in editor rather than manual YAML.

UPDATE: 5 playable characters (C key / menu button), 5 zombie types (runner, brute),
health bar + medkits (white), sniper (yellow, pierces), blood, night look + moon/stars/lamp lights,
new gun/heal/splat/hurt sounds. Footstep and jump sounds removed.
