using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
[InitializeOnLoad]
public static class DeadCitySetup{
 static DeadCitySetup(){EditorApplication.delayCall+=Init;}
 static void Init(){if(!EditorApplication.isPlayingOrWillChangePlaymode&&!System.IO.File.Exists("Assets/DeadCity.unity"))Create();}
 [MenuItem("Dead City/Create or Reset Game Scene")]
 static void Create(){if(!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())return;var s=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);new GameObject("Dead City Game").AddComponent<DeadCityGame>();EditorSceneManager.SaveScene(s,"Assets/DeadCity.unity");EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/DeadCity.unity",true)};}
}
